::: center
**Alaa SAAD**\
**Gestion Financière & Comptable    Corporate Finance\**
\[5pt\] Casablanca, Maroc 06 48 09 13 50 <alaa.saad1305@gmail.com>
[LinkedIn : alaa-saad](https://www.linkedin.com/in/alaa-saad-980477294/)
[GitHub : saadalaa-encg](https://github.com/saadalaa-encg)
:::

# Profil

Étudiante en M1 Gestion Financière et Comptable à l'ENCG Settat,
passionnée par le **Corporate Finance** et l'**ingénierie financière**.
Expériences en **audit interne** (RMA) et en **comptabilité** (cabinet
fiduciaire), avec de solides bases en analyse financière, valorisation
d'entreprises et business plan.

# Formation

**École Nationale de Commerce et de Gestion (ENCG) Settat**Settat, Maroc
2023 -- Présent\
*Diplôme en Gestion Financière et Comptable (GFC) -- en cours*

- Cours clés : Finance d'entreprise, Analyse financière, Comptabilité,
  Contrôle de gestion, Droit des sociétés.

**Faculté des Sciences et Techniques (FST) Settat**Settat, Maroc 2022 --
2023\
*Génie Électrique & Génie Mécanique*

**Groupe Scolaire Rahmouni Potentiel**Casablanca, Maroc 2021 -- 2022\
*Baccalauréat Sciences Physiques -- Mention Très Bien*

# Expériences professionnelles

**Cabinet Fiduciaire**Casablanca Janvier 2026\
*Assistante Comptable -- Stage*

- Saisie des opérations comptables sur **Sage 100** et tenue des
  journaux.

- Préparation des déclarations fiscales (**TVA, IS, IR**) et
  rapprochements bancaires.

- Participation à la clôture comptable, à l'établissement des états
  financiers et au suivi des dossiers clients.

**Royale Marocaine d'Assurance (RMA)**Casablanca Juillet 2025\
*Assistante Audit Interne -- Stage*

- Analyse et justification des écarts dans les processus opérationnels
  et financiers.

- Conception de rapports de suivi pour appuyer la prise de décision
  stratégique.

- Analyse de données financières avec **Excel** (TCD, automatisations)
  et **SQL**.

- Contribution à la vérification de la conformité réglementaire.

# Projets académiques

**Création de la coopérative « MADAQ »**Projet de fin d'année 2023 --
2024\
*Business plan et évaluation financière*

- Élaboration d'un business plan complet : étude de marché, plan de
  financement et analyse de rentabilité.

- Projection des flux de trésorerie et analyse de scénarios
  d'investissement.

- Structuration d'un dossier de financement assorti de recommandations
  stratégiques.

**Étude de marché -- Secteur de la restauration**Projet marketing 2024
-- 2025

- Benchmark international et recommandations stratégiques pour le
  repositionnement de l'enseigne.

# Compétences

**Finance :** Analyse financière, Valorisation d'entreprises, Business
plan, Comptabilité générale, Fiscalité (TVA, IS, IR), Audit interne

**Outils :** MS Office (avancé), Excel (TCD, VBA), Power BI, SQL,
Python, Sage 100, SPSS

**Langues :** Arabe (langue maternelle), Français (courant), Anglais
(professionnel)

# Certifications

- Advanced Microsoft Excel -- *365 Data Science*

- Growth Analysis with SQL, Python & Tableau -- *365 Data Science*

- Econometrics: Methods and Applications -- *Erasmus University
  Rotterdam (Coursera)*

# Activités parascolaires

- **Club Médiatique ESPress** (2023 -- Présent) : Responsable
  Communication ; Cheffe de projet de la Nuit des Oscars (7^e^ éd.) et
  animatrice (8^e^ éd.) ; 3^e^ place au concours de filmmaking
  CINEXPRESS.

- **TEDxENCG Settat** (Fév. 2026) : Organisation pré- et post-événement
  « The Unlearning ».

- **Club C2P** (2025 -- Présent) : Organisation des JPO et du forum
  d'orientation des bacheliers (TAFEM).

- **Club GENIE** (2023 -- 2024) : Membre active -- organisation de The
  Pitch, Agora et ateliers de coaching.

**Centres d'intérêt :** Création de contenu et communication digitale,
Cinéma & filmmaking, Finance comportementale, Rédaction.
