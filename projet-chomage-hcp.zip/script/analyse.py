"""
Pourquoi le taux de chômage augmente-t-il sans cesse au Maroc ?
Analyse à partir des données du Haut-Commissariat au Plan (HCP), 2020-2025.

Ce script :
1. Importe le dataset data/chomage_diplome_milieu.csv (déjà construit à partir
   des bulletins annuels du HCP "Activité, emploi et chômage" ; voir les
   sources dans la colonne source_url du fichier).
2. Met les données en forme (tableau année x indicateur).
3. Calcule quelques statistiques simples (variation totale, écart diplômés /
   sans diplôme, écart urbain / rural).
4. Génère deux graphiques dans figures/ :
   - chomage_national_diplome.png : national, diplômés, sans diplôme
   - chomage_milieu.png           : national, urbain, rural

Utilisation :
    pip install -r requirements.txt
    python script/analyse.py
"""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

RACINE = Path(__file__).resolve().parent.parent
DATA = RACINE / "data"
FIGURES = RACINE / "figures"
FIGURES.mkdir(exist_ok=True)


def charger_donnees():
    """Importe le CSV et le met en forme (une colonne par indicateur)."""
    brut = pd.read_csv(DATA / "chomage_diplome_milieu.csv")
    df = brut.pivot(index="annee", columns="indicateur", values="valeur")
    df = df.sort_index()
    return df


def statistiques(df):
    lignes = [
        "RESULTATS DE L'ANALYSE (source : HCP, bulletins annuels 2020-2025)",
        f"Chômage national en 2020 : {df.loc[2020, 'national']:.1f} %",
        f"Chômage national en 2025 : {df.loc[2025, 'national']:.1f} %",
        f"Variation 2020-2025 : {df.loc[2025, 'national'] - df.loc[2020, 'national']:+.1f} point(s)",
        f"Chômage national le plus haut : {df['national'].max():.1f} % ({df['national'].idxmax()})",
        f"Chômage national le plus bas : {df['national'].min():.1f} % ({df['national'].idxmin()})",
        f"Ecart diplômés - sans diplôme en 2025 : {df.loc[2025, 'diplomes'] - df.loc[2025, 'sans_diplome']:.1f} points",
        f"Ecart urbain - rural en 2025 : {df.loc[2025, 'urbain'] - df.loc[2025, 'rural']:.1f} points",
        f"Ecart urbain - rural, moyenne 2020-2025 : {(df['urbain'] - df['rural']).mean():.1f} points",
    ]
    texte = "\n".join(lignes)
    (DATA / "resultats.txt").write_text(texte + "\n", encoding="utf-8")
    return texte


def graphique_national_diplome(df):
    fig, ax = plt.subplots(figsize=(9, 5.5))
    couleurs = {"national": "#7b1c3a", "diplomes": "#d98a2b", "sans_diplome": "#2e7d6b"}
    noms = {"national": "National", "diplomes": "Diplômés", "sans_diplome": "Sans diplôme"}
    for col in ["diplomes", "national", "sans_diplome"]:
        ax.plot(df.index, df[col], marker="o", linewidth=2.5, label=noms[col], color=couleurs[col])
        for x, y in zip(df.index, df[col]):
            ax.annotate(f"{y}", (x, y), textcoords="offset points", xytext=(0, 8),
                        ha="center", fontsize=9)
    ax.set_title("Taux de chômage selon le diplôme (Maroc, 2020-2025)", fontsize=13, fontweight="bold")
    ax.set_xlabel("Année")
    ax.set_ylabel("Taux de chômage (%)")
    ax.set_xticks(df.index)
    ax.set_ylim(0, 22)
    ax.grid(axis="y", linestyle="--", alpha=0.5)
    ax.legend(title="Catégorie")
    plt.figtext(0.5, 0.01, "Source : HCP, bulletins annuels \"Activité, emploi et chômage\" (2020-2025).",
                ha="center", fontsize=8)
    plt.tight_layout(rect=(0, 0.03, 1, 1))
    plt.savefig(FIGURES / "chomage_national_diplome.png", dpi=150)
    plt.close(fig)


def graphique_milieu(df):
    fig, ax = plt.subplots(figsize=(9, 5.5))
    couleurs = ["#7b1c3a", "#d98a2b", "#2e7d6b"]
    df[["national", "urbain", "rural"]].rename(
        columns={"national": "National", "urbain": "Urbain", "rural": "Rural"}
    ).plot(kind="bar", ax=ax, color=couleurs)
    ax.set_title("Taux de chômage selon le milieu (Maroc, 2020-2025)", fontsize=13, fontweight="bold")
    ax.set_xlabel("Année")
    ax.set_ylabel("Taux de chômage (%)")
    ax.set_xticklabels(df.index, rotation=0)
    ax.grid(axis="y", linestyle="--", alpha=0.5)
    ax.legend(title="Milieu")
    plt.figtext(0.5, 0.01, "Source : HCP, bulletins annuels \"Activité, emploi et chômage\" (2020-2025).",
                ha="center", fontsize=8)
    plt.tight_layout(rect=(0, 0.03, 1, 1))
    plt.savefig(FIGURES / "chomage_milieu.png", dpi=150)
    plt.close(fig)


if __name__ == "__main__":
    df = charger_donnees()
    print(df)
    print()
    print(statistiques(df))
    graphique_national_diplome(df)
    graphique_milieu(df)
    print("\nFigures enregistrées dans figures/ :")
    print(" - chomage_national_diplome.png")
    print(" - chomage_milieu.png")
