# Pourquoi le taux de chômage augmente-t-il sans cesse au Maroc ?

Projet du module *Bases de données et Data Science* (4e année Finance), basé sur les données du Haut-Commissariat au Plan (HCP).

## Contenu

| Fichier | Rôle |
|---|---|
| `rapport.md` | Rapport complet : données, code, graphiques, interprétation |
| `script/analyse.py` | Importe le dataset, calcule les statistiques et génère les graphiques |
| `data/chomage_diplome_milieu.csv` | Dataset : taux de chômage 2020-2025 par milieu et par diplôme, avec la source de chaque valeur |
| `data/resultats.txt` | Statistiques générées automatiquement par le script |
| `figures/` | Les deux graphiques produits par le script |
| `requirements.txt` | Bibliothèques Python nécessaires |

## Source des données

Haut-Commissariat au Plan (HCP), bulletins annuels *« Activité, emploi et chômage »* (2020 à 2025) et base de données statistiques en ligne : https://bds.hcp.ma. Le détail des URL utilisées se trouve dans la colonne `source_url` du fichier CSV et dans la section « Sources » du rapport.

## Exécution

```bash
pip install -r requirements.txt
python script/analyse.py
```

Le script régénère `data/resultats.txt` et les deux figures dans `figures/` à partir du CSV.
