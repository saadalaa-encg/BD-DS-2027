# Pourquoi le taux de chômage augmente-t-il sans cesse au Maroc ?

Module : Bases de données et Data Science — 4e année Finance

---

## 1. Introduction

Le taux de chômage est régulièrement présenté comme un problème qui « ne fait qu'augmenter » au Maroc. Avant d'expliquer une hausse, il faut d'abord vérifier qu'elle a bien lieu, avec des chiffres. Ce travail utilise les données officielles du Haut-Commissariat au Plan (HCP) sur la période 2020-2025 pour répondre à deux questions :

1. Le taux de chômage nationale a-t-il vraiment augmenté sans cesse ?
2. Pourquoi reste-t-il élevé et pourquoi touche-t-il si inégalement la population ?

**Thèse défendue :** le chômage marocain ne suit pas une trajectoire de hausse continue ; il oscille entre 11,8 % et 13,3 % depuis 2020. En revanche, il est structurellement plus élevé chez les diplômés que chez les non-diplômés, et beaucoup plus élevé en ville qu'à la campagne. C'est cette **persistance et ces écarts**, plus qu'une hausse continue, qu'il faut expliquer.

---

## 2. Le dataset utilisé

### 2.1 Source

Les données proviennent des bulletins annuels du HCP *« Activité, emploi et chômage »*, publiés chaque début d'année (janvier-février) pour l'année précédente. Chaque bulletin annonce le taux de l'année en cours et celui de l'année précédente, ce qui permet de reconstituer une série continue en recoupant les bulletins deux par deux.

| Année couverte | Bulletin HCP utilisé |
|---|---|
| 2020-2021 | https://www.hcp.ma/file/233290/ |
| 2022 | https://www.hcp.ma/Activite-emploi-et-chomage-resultats-annuels-2022_a3711.html |
| 2023 | https://www.hcp.ma/Activite-emploi-et-chomage-resultats-annuels-2023_a3873.html |
| 2024 | https://www.hcp.ma/Activite-emploi-et-chomage-resultats-annuels-2024_a4142.html |
| 2025 | https://www.hcp.ma/Situation-du-marche-du-travail-en-2025_a4248.html |

Ces bulletins reprennent les résultats de l'Enquête Nationale sur l'Emploi (ENE) du HCP, également consultable de façon interactive sur la base de données statistiques du HCP : https://bds.hcp.ma.

**Vérification :** chaque valeur apparaît dans deux bulletins consécutifs (par exemple le taux de 2022 est donné à la fois par le bulletin 2022 et par le bulletin 2023, comme année de référence). Les deux sources concordent pour toutes les valeurs retenues, ce qui garantit la fiabilité de la série reconstituée.

### 2.2 Indicateurs retenus

Le fichier `data/chomage_diplome_milieu.csv` contient, pour chaque année de 2020 à 2025, le taux de chômage (en %) selon cinq découpages :

- **national** : taux de chômage pour l'ensemble du pays ;
- **urbain** / **rural** : taux de chômage selon le milieu de résidence ;
- **diplomes** : taux de chômage des personnes titulaires d'un diplôme (tous niveaux confondus) ;
- **sans_diplome** : taux de chômage des personnes sans aucun diplôme.

Chaque ligne du fichier précise l'année, l'indicateur, la valeur et l'URL exacte de la source. C'est cette table qui joue le rôle de base de données pour ce travail.

### 2.3 Limite

Le HCP publie aussi une nouvelle mesure du chômage (« chômage strict », enquête EMO2026) depuis le T2 2026, non comparable aux données annuelles utilisées ici. Cette analyse s'arrête donc à l'année 2025, dernière année disponible avec l'ancienne méthode, pour garder une série homogène.

---

## 3. Conversion en représentation graphique

Le script `script/analyse.py` importe le CSV avec `pandas`, le met en forme (un tableau avec une colonne par indicateur), calcule quelques statistiques puis trace les graphiques avec `matplotlib`.

```python
import pandas as pd
import matplotlib.pyplot as plt

def charger_donnees():
    brut = pd.read_csv("data/chomage_diplome_milieu.csv")
    df = brut.pivot(index="annee", columns="indicateur", values="valeur")
    return df.sort_index()

df = charger_donnees()

# --- Graphique 1 : national, diplômés, sans diplôme ---
couleurs = {"national": "#7b1c3a", "diplomes": "#d98a2b", "sans_diplome": "#2e7d6b"}
noms = {"national": "National", "diplomes": "Diplômés", "sans_diplome": "Sans diplôme"}
fig, ax = plt.subplots(figsize=(9, 5.5))
for col in ["diplomes", "national", "sans_diplome"]:
    ax.plot(df.index, df[col], marker="o", linewidth=2.5, label=noms[col], color=couleurs[col])
ax.set_title("Taux de chômage selon le diplôme (Maroc, 2020-2025)")
ax.set_xlabel("Année"); ax.set_ylabel("Taux de chômage (%)")
ax.legend(title="Catégorie")
plt.savefig("figures/chomage_national_diplome.png", dpi=150)

# --- Graphique 2 : national, urbain, rural ---
fig, ax = plt.subplots(figsize=(9, 5.5))
df[["national", "urbain", "rural"]].plot(kind="bar", ax=ax,
                                          color=["#7b1c3a", "#d98a2b", "#2e7d6b"])
ax.set_title("Taux de chômage selon le milieu (Maroc, 2020-2025)")
plt.savefig("figures/chomage_milieu.png", dpi=150)
```

Le script complet (avec la gestion des chemins, les étiquettes de valeurs et le calcul des statistiques) se trouve dans `script/analyse.py`.

---

## 4. Représentation graphique

![Taux de chômage selon le diplôme](figures/chomage_national_diplome.png)

*Figure 1 : évolution du taux de chômage national, des diplômés et des personnes sans diplôme (2020-2025).*

![Taux de chômage selon le milieu](figures/chomage_milieu.png)

*Figure 2 : taux de chômage national, urbain et rural (2020-2025).*

**Résultats calculés par le script** (fichier `data/resultats.txt`) :

- Chômage national 2020 : 11,9 % → chômage national 2025 : 13,0 % (variation : **+1,1 point** en six ans, ce n'est pas une hausse continue mais un passage par un creux en 2022).
- Point le plus bas : **11,8 % en 2022**. Point le plus haut : **13,3 % en 2024**.
- Écart diplômés / sans diplôme en 2025 : **14,4 points** (19,1 % contre 4,7 %).
- Écart urbain / rural en 2025 : **9,8 points** (16,4 % contre 6,6 %), et en moyenne **10,5 points** sur toute la période.

---

## 5. Interprétation

**Une stagnation en dents de scie, pas une hausse continue.** Le taux national passe de 11,9 % (2020) à 12,3 % (2021), redescend à 11,8 % (2022) — son point le plus bas de la période — avant de remonter à 13,0 % (2023), 13,3 % (2024) et de refluer légèrement à 13,0 % (2025). L'affirmation d'une hausse « sans cesse » ne correspond donc pas aux chiffres : le chômage marocain **oscille autour de 12-13 %** depuis 2020, avec un rebond après le creux de 2022 plutôt qu'une tendance linéaire.

**Le rebond de 2022 à 2023 a une explication conjoncturelle.** Le passage de 11,8 % à 13,0 % coïncide avec la sécheresse sévère de 2022-2023 (l'agriculture a perdu 41 000 à 157 000 emplois selon les années) et avec le ralentissement de l'économie mondiale post-inflation. Ce n'est pas un dérapage structurel soudain, mais un choc sur un secteur (l'agriculture) qui reste un employeur majeur en zone rurale.

**Le vrai clivage n'est pas dans le temps, il est entre catégories.** L'écart entre diplômés et non-diplômés est resté élevé et stable sur toute la période (entre 13 et 15 points). Un diplômé a donc, chaque année depuis 2020, un risque de chômage 3 à 4 fois supérieur à celui d'une personne sans diplôme. Cela s'explique par le fait que les non-diplômés travaillent massivement dans l'agriculture, le BTP ou l'informel, des secteurs qui absorbent facilement de la main-d'œuvre peu qualifiée, alors que les diplômés recherchent des emplois formels (administration, secteur privé structuré) dont le nombre de postes créés ne suit pas le nombre de diplômés produits chaque année par le système éducatif.

**Le fossé urbain/rural est le plus stable et le plus large des deux écarts.** Il oscille entre 9,8 et 11,9 points sur toute la période, sans jamais se refermer. Ce résultat confirme que le marché du travail urbain est structurellement saturé : la ville concentre les diplômés, les jeunes en recherche d'un premier emploi formel et l'exode rural, alors que la campagne « absorbe » sa main-d'œuvre dans l'agriculture familiale, souvent en sous-emploi plutôt qu'en chômage déclaré.

**En résumé**, le problème du Maroc n'est pas une hausse continue et générale du chômage, mais sa persistance à un niveau élevé (12-13 %) combinée à deux inégalités stables dans le temps : un chômage des diplômés environ quatre fois supérieur à celui des non-diplômés, et un chômage urbain environ deux à trois fois supérieur au chômage rural. Cette persistance s'explique par une croissance économique qui ne crée pas assez d'emplois qualifiés et formels pour absorber les diplômés urbains, pendant que le monde rural masque une partie de son sous-emploi derrière un faible taux de chômage apparent.

---

## 6. Conclusion et pistes

Le Maroc doit résoudre un problème de **composition** du chômage plus qu'un problème de **tendance**. Trois pistes se dégagent des chiffres :

- Créer davantage d'emplois qualifiés en ville, notamment dans les secteurs à forte valeur ajoutée, pour absorber le flux annuel de diplômés.
- Réduire l'inadéquation entre les filières de formation et les besoins réels des entreprises, pour faire baisser le chômage des diplômés sans réduire l'accès à l'éducation.
- Accompagner la transition du travail agricole informel vers des emplois ruraux plus stables, pour que la baisse du chômage rural apparent ne masque pas une dégradation réelle des conditions de travail (sous-emploi).

**Limite du travail** : cette analyse repose sur des taux annuels agrégés au niveau national. Elle ne permet pas d'établir un lien de causalité, et pourrait être prolongée par une décomposition régionale ou par l'ajout de la croissance du PIB pour tester la sensibilité du chômage au cycle économique.

---

## Annexe : contenu du dépôt

```
mon-projet/
├── rapport.md
├── requirements.txt
├── data/
│   ├── chomage_diplome_milieu.csv   (dataset, avec source de chaque valeur)
│   └── resultats.txt                (statistiques générées par le script)
├── script/
│   └── analyse.py
└── figures/
    ├── chomage_national_diplome.png
    └── chomage_milieu.png
```

Pour reproduire l'analyse : `pip install -r requirements.txt` puis `python script/analyse.py`.

## Sources

- HCP, *Activité, emploi et chômage, résultats annuels 2020-2021* : https://www.hcp.ma/file/233290/
- HCP, *Activité, emploi et chômage, résultats annuels 2022* : https://www.hcp.ma/Activite-emploi-et-chomage-resultats-annuels-2022_a3711.html
- HCP, *Activité, emploi et chômage, résultats annuels 2023* : https://www.hcp.ma/Activite-emploi-et-chomage-resultats-annuels-2023_a3873.html
- HCP, *Activité, emploi et chômage, résultats annuels 2024* : https://www.hcp.ma/Activite-emploi-et-chomage-resultats-annuels-2024_a4142.html
- HCP, *Situation du marché du travail en 2025* : https://www.hcp.ma/Situation-du-marche-du-travail-en-2025_a4248.html
- HCP, base de données statistiques (BDS), en ligne : https://bds.hcp.ma
